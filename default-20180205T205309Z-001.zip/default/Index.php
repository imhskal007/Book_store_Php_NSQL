<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bookstore</title>
<style type="text/css">
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #84DBD7;
	background-image:url(../images/bookstorelogo.png)
	background-position: center -96px;
	background-repeat: no-repeat;
	background-size: 100%;
}
h3 {
	font-size: 16px;
	color: #0F5E40;
	font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
}
/*</style>
<link href="css/mainbody.css" rel="stylesheet" type="text/css" />
<link href="css/Menu.css" rel="stylesheet" type="text/css" />
<style type="text/css">*/
#SearchField {	height: 35px;
	width: 200px;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 16px;
	padding-top: 1px;
	padding-right: 1px;
	padding-bottom: 1px;
	padding-left: 3px;
	border: 1px solid #F7F7F7;
}
a:link {
	color: #000000;
	text-decoration: none;
}
a:visited {
	color: #000000;
	text-decoration: none;
}
a:hover {
	color: #000000;
	text-decoration: none;
}
a:active {
	color: #000000;
	text-decoration: none;
}
#Thumb {	width:260px;
	height:145px;
}
.Donate {
	background-color:rgb(255, 18, 0);
	color:#F00;
}
</style>
</head>

<body>
<div id="Header"><img src="../images/logo.png" width="366" height="97" /></div>
    </div>
<div id="Banner">
      <table border="0">
    <tr>
      <td width="254" align="left" valign="middle"><form id="SearchForm" name="SearchForm" method="post" action="results.php">
        <label for="SearchField6"></label>
        <table border="0">
          <tr>
            <td><input type="text" name="SearchField" id="SearchField" /></td>
            <td><input name="SearchButton" type="image" id="SearchButton" value="Submit" src="../images/search.png" width="55" height="80" /></td>
          </tr>
        </table>
        <table cellpadding="2" cellspacing="0" border="0">
          <tr>
            <td align="center"><input type="hidden" name="WADbSearch1" value="Submit" /></td>
          </tr>
        </table>
      </form></td>
      <td width="220"><a href="Login.php"> <img src="../images/Existinguser_login.png" width="315" height="63" /></a></td>
      <td width="1">&nbsp;</td>
      <td width="220"><a href="RegisterUser.php"> <img src="../images/Newuser_Register.png" width="312" height="63" /></a></td>
    </tr>
  </table>
 
</div>
</body>
</html>
