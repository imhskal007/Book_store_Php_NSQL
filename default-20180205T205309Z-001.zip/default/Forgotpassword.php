<? php
mysql_connect ("localhost:3306", "root" ,"");
mysql_select_db ("Bookstore");
$result=mysql_query("SELECT title,bookid,ISBN,Author from book);
?>